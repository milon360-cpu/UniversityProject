import React from 'react';
import './Home.css'
import img from '../Images/ideapng.png';
import Service from '../Services/Service';
import Team from '../Team/Team';
import Data from '../Services/Data.json';
import TeamData from "../Team/Team.json"

const Home = () => {

    return (
        <div className="cover">
         <div className='home-container'>
            {/* header section here  */}
           <div className="header">
               <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, </h1>
               <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Expedita consequatur vero doloremque iusto, officia ullam quisquam quibusdam quas incidunt. Deleniti.</p>

           </div>
           <div className="btn">
                <button>GET STARTED</button>
           </div>         
        </div>

        {/* Busimess Idea seaction  */}
        <div className="business-idea">
            <div className="details">
              <h1>Business Idea</h1>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero non accusamus odio similique? Pariatur eligendi inventore molestiae veritatis amet fugit, aut repellendus, adipisci quasi aperiam corporis illum, doloremque ex neque repellat veniam cum deserunt dolor voluptatem nostrum nesciunt mollitia! Impedit non dicta voluptatem quos, modi quis saepe, aperiam cum consequuntur tempora eum dolore nisi nostrum quidem recusandae at laboriosam sequi doloribus reiciendis voluptatibus, eos excepturi cumque. Ullam natus fuga, quibusdam quis iusto nobis amet sapiente temporibus! Adipisci doloribus sint officiis repudiandae maxime porro fugit modi et unde quibusdam assumenda voluptatum commodi dignissimos praesentium, alias eum, animi cumque incidunt illum rem?.....</p>
              <button className='idea-btn'>Read more</button>
            </div>
            <div className="image">
               <img src={img} alt="idea" />
            </div>
        </div>
        {/* Service Container  */}
        <div className="service-container">
            <h1 className='service-header'>Our Services</h1>
            <div className="services">
                {
                  Data.map((data)=>
                  {
                      return(
                      <Service serviceInfo = {data}></Service>
                      )
                  })
                }
                
            </div>
        </div>
        {/* Our Team  */}
        <div className="teamContainer">
            <h1 className='teamHeader'>Our Team</h1>
            <div className="teamService">
                {
                  TeamData.map((data)=>
                  {
                      return(
                          <Team teamInfo = {data}></Team>
                      )
                  })
                }
                
            </div>
        </div>
    </div>
    );
};

export default Home;