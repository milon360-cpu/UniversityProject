import React from 'react';
import './Footer.css';
import {FaFacebook,FaTwitter,FaGoogle,FaWhatsapp} from "react-icons/fa";

const Footer = () => {
    
    return (
        <div className='footer-container'>
             <footer className='footer'>
                <div className="footer-contact">
                    <h1>Contact</h1>
                    <p>Phone: 01771341302</p>
                    <p>Address: 315/3 Dhanmondi Dhaka</p>
                    <p>Email: heymilon@gmail.com</p>
                </div>
                <div className="footer-icon">
                  <a href='https://www.facebook.com/' target="_blank"><FaFacebook /></a> 
                  <a href='https://www.facebook.com/' target="_blank"><FaTwitter></FaTwitter></a>
                  <a href='https://www.facebook.com/' target="_blank"><FaGoogle></FaGoogle></a>
                  <a href='https://www.facebook.com/' target="_blank"><FaWhatsapp></FaWhatsapp></a>
                </div>
                <div className="footer-service-section">
                    <h1>Services</h1>
                    <p>SEO</p>
                    <p>Facebook Marketing</p>
                    <p>Youtube Marketing</p>
                    <p>Google Ads</p>
                    <p>Email Marketing</p>
                    <p>Photography</p>
                </div>
             </footer>
             <hr className='hr' />
             <p className='copy-right'>@copy right 2022</p>
        </div>
    );
};

export default Footer;