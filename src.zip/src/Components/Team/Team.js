import React from 'react';
import './Team.css'
import { FaUserAlt } from "react-icons/fa";
const Team = (props) => {
    const{name,deg,det} = props.teamInfo;
    return (
        <div className='makeTeam'>
            <h1  className='team-icon'><FaUserAlt></FaUserAlt></h1>
            <hr  />
            <h1>{name}</h1>
            <p>{deg}</p>
            <p className='details'>{det}</p>
            
        </div>
    );
};

export default Team;