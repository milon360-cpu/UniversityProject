import React, { useState } from 'react';
import {NavLink} from 'react-router-dom';
import "./Nav.css"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBars } from '@fortawesome/free-solid-svg-icons'
const element = <FontAwesomeIcon icon={faBars} />

const Nav = () => {
    const[isOpen,setIsOpen] = useState(false);
    const OpenToggle = ()=>
    {
        if(isOpen==false)
        {
            document.querySelector(".nav-item").style.right = "0px";
            setIsOpen(true);
            setTimeout(()=>
            {
                document.querySelector(".nav-item").style.right = "-300px";
            },3000);
        }
        else if(isOpen==true)
        {
            
                document.querySelector(".nav-item").style.right = "-300px";
                setIsOpen(false)
            
        }
    }
    
    return (
        <div className='Nav-menu'>
            <nav className='nav-bar'>
                <div className="logo">
                    <NavLink to="/" className={"nav-logo"}>NEXUS IT</NavLink>
                </div>
                <div className="nav-item">
                    <NavLink to = "/" className="nav-link">HOME</NavLink>
                    <NavLink to = "/contact"  className="nav-link">CONTACT</NavLink>
                    <NavLink to = "/registry"  className="nav-link">REGISTRY</NavLink>
                    <NavLink to = "/about"  className="nav-link">ABOUT</NavLink>                  
                </div>
                <div className="toggle">
                    <button onClick={()=>
                    {
                        OpenToggle();
                    }}>{element}</button>
                    
                </div>
            </nav>
        </div>
    );
};

export default Nav;