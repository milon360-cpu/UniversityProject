import React from 'react';
import {useState} from 'react';
import "./Registry.css"
const Registry = () => {
    const [userName,setName] = useState("");
    const [userPassword, setPassword] = useState("");
    const [language, setlanguage] = useState("");
    const [gender, setGender] = useState("");
    const [university,setUniversity] = useState("");
    const [file,setFile] = useState('');

     const handelName = (e)=>
     {
        setName(e.target.value);
     }
     const handelPassword = (e)=>
     {
        setPassword(e.target.value)
     }
     const checkBox = (e)=>
     {
        setlanguage(e.target.value);
     }
     const handelRadio = (e)=>
     {
        setGender(e.target.value);
     }
     const handelOption = (e)=>
     {
        setUniversity(e.target.value);
     }
     const handelFile =(e)=>
     {
        setFile(e.target.value);
     }
    const submitData= (e)=>
    {
        const allInfo = 
        {
            name:userName,
            password:userPassword,
            language:language,
            gender:gender,
            university:university,
            file : file
        }
    //   e.preventDefault();        
    }
//    mySql Connection here
//    const mysql = require('mysql');
    // var databaseConnection = 
    // {
    //     host:"localhost",
    //     user:'root',
    //     password:''
    // }
    // let connection = mySql.createConnection(databaseConnection);
    // connection.connect((error)=>
    // {
    //     if(error)
    //     {
    //         console.log("error");
    //     }
    //     else 
    //     {
    //         console.log("success");
    //     }
    // })

    return (
        <div className='information-container'>
            <div className="info">
                <form action="" className='form' onSubmit={submitData}>
                    <h1 className='form-header'>Registration Form</h1>
                    <hr />
                    <div className="info-container">
                        <label htmlFor="name" className='user-name'>Name</label><br />
                        <input type="text" name="name" id="userName" className='input-filed' placeholder='name' required onChange={handelName}/>
                    </div>
                   <div className="info-container">
                       <label htmlFor="password" className='user-password'>Password</label> <br />
                       <input type="password" name="password" id="userPassword" className='input-filed' placeholder='password'required maxLength={14} minLength={8}onChange={handelPassword} />
                   </div>
                    <div className="info-container" onChange={checkBox}>
                       <label className='lg'>Select Your Language</label><br />
                       <label htmlFor="checkbox"  className='checkbox'>Java</label>
                       <input type="checkbox" name="checkbox" className='checkbox' value="Java" />

                       <label htmlFor="checkbox"className='checkbox' >Python</label>
                       <input type="checkbox" name="checkbox" className='checkbox' value='Python'/>

                       <label htmlFor="checkbox" className='checkbox'>C</label>
                       <input type="checkbox" name="checkbox" className='checkbox' value='C'/>

                       <label htmlFor="checkbox" className='checkbox'>Js</label>
                       <input type="checkbox" name="checkbox" className='checkbox' value='Js'/>
                    </div>
                    <div className="info-container" onChange={handelRadio}>
                        <label className='lg'>Gender</label><br />
                       <label htmlFor="Gender" className='gender'>male</label>
                       <input type="radio" name="gender" className='gender' value='male'/>

                       <label htmlFor="Gender" className='gender'>Female</label>
                       <input type="radio" name="gender" className='gender'value='female'/>

                       <label htmlFor="Gender" className='gender'>custom</label>
                       <input type="radio" name="gender" className='gender' value='custom'/>
                   </div>
                   <div className="info-container">
                       <label className='lg'> Select University</label><br />
                        <select name="select" id="" onChange={handelOption}>                          
                            <option value="UODA" className='option' >UODA</option>
                            <option value="BUBT" className='option'>BUBT</option>
                            <option value="AIUB" className='gender'>AIUB</option>
                            <option value="NSU" className='option'>NSU</option>
                        </select>
                   </div>
                   <div className="info-container">
                       <label htmlFor="file"  className='lg'>Add Your File</label><br />
                       <input type="file" name="file" id="file" className='lg' onChange={handelFile}/>
                    </div>
                    <div className="btn-container">
                        <button type='submit' className='submit'>submit</button>
                        <button  className='reset' type="reset">reset</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Registry;