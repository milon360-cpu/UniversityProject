import React from 'react';
import "./Service.css"
import { FaServicestack} from 'react-icons/fa';
const Service = (props) => {
    const {icon,Header,des} = props.serviceInfo;
    return (
        <div className='service'>
            <h1 className='service-icon'><FaServicestack></FaServicestack></h1>
            <h1>{Header}</h1>
            <p>{des}</p>
            <button className='service-btn'>Read more</button>
            
        </div>
    );
    
};

export default Service;