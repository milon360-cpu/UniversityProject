import React from 'react';
import "./About.css"
import {FaFacebook,FaTwitter,FaGoogle,FaWhatsapp} from "react-icons/fa";
const About = () => {
    return (
        <div className='nexus-container'>
            <div className="about-nexus">
                <h1>Nexus It</h1>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem adipisci officiis dolor. Accusamus, eveniet quos enim iste blanditiis quas temporibus aut veniam repellendus accusantium, autem vitae quidem id cumque consequatur animi repellat nam libero maxime officia minima! Laudantium, vel? Vero atque adipisci ea repellat! Voluptatibus magnam, rem laboriosam animi sit aspernatur dicta quasi possimus, et eaque itaque dolorum repudiandae iusto.
                </p>
                <br />
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis quidem quasi perferendis corporis molestiae labore minima amet, itaque officia, consequuntur facere quibusdam debitis molestias reiciendis praesentium excepturi dignissimos ab doloremque, provident omnis laborum natus! Deserunt, distinctio cupiditate. Ipsum, eos libero. Aspernatur ipsum illum excepturi, tempora voluptatum illo eveniet veniam ipsam.
                </p>
                <br />
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus dolorum, distinctio facere ab culpa vero eaque dolores molestiae cumque natus libero minus, expedita voluptas voluptate nobis quae. Blanditiis veritatis nam quas culpa impedit consectetur rem veniam quod sint necessitatibus. Totam ipsa perferendis commodi doloremque eos! Illo, temporibus minima doloribus debitis natus quis placeat magnam dolor inventore corporis nobis aspernatur vel ea alias suscipit exercitationem accusantium quae tempora rerum voluptas soluta!
                </p>
                <br />
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident facilis deleniti repellendus non vitae incidunt, iste dolores cumque, placeat in, quasi nulla ad ipsa. Iusto qui quaerat dolores nobis at accusantium maiores reprehenderit deserunt, doloribus porro odio nisi a esse!
                </p>
                <div className="social-icon">
                    <a href="https://www.facebook.com/"><FaFacebook></FaFacebook></a>
                    <a href="https://www.facebook.com/"><FaTwitter></FaTwitter></a>
                    <a href="https://www.facebook.com/"><FaGoogle></FaGoogle></a>
                    <a href="https://www.facebook.com/"><FaWhatsapp></FaWhatsapp></a>
                </div>
            </div>
        </div>
    );
};

export default About;