import React from 'react';
import './Contact.css'
const Contact = () => {
    return (
        <div className='content-container'>
            <div className="contact">
                <form action="">
                    <div className="msg-box">
                       <textarea name="" id="" cols="30" rows="10" placeholder='Write Your Massage Here' maxLength={250}></textarea>
                    </div>                   
                    <div className="submit-btn">
                        <button type='submit'>Submit</button>
                    </div>
                     
                </form>
            </div>
        </div>
    );
};

export default Contact;