import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
// pages 
import Home from './Components/Home/Home';
import Contact from './Components/Contact/Contact';
import About from './Components/About/About';
import Registry from './Components/Registry/Registry';
import Nav from './Components/Navigation/Nav';
import Footer from './Components/Footer/Footer';
function App() {
  return (
    <div className="App">
       <BrowserRouter>
       <Nav></Nav>
         <Routes>
           <Route path = "/" element = {<Home></Home>}></Route>
           <Route path = "/contact" element = {<Contact></Contact>}></Route>
           <Route path = "/registry" element = {<Registry></Registry>}></Route>
           <Route path = "/about" element = {<About></About>}></Route>
         </Routes>
       </BrowserRouter>
       <Footer></Footer>
    </div>
  );
}

export default App;
